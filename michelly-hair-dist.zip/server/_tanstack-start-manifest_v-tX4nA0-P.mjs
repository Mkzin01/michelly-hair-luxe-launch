//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-tX4nA0-P.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/dev-server/src/routes/__root.tsx",
		children: ["/", "/servicos"],
		preloads: ["/assets/index-DjcsFDsB.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DjcsFDsB.js"
		} }]
	},
	"/": {
		filePath: "/dev-server/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-C8DUpMEB.js", "/assets/tratamentos.jpg.asset-DOlNU08t.js"]
	},
	"/servicos": {
		filePath: "/dev-server/src/routes/servicos.tsx",
		children: void 0,
		preloads: ["/assets/servicos-DrKvVgnV.js", "/assets/tratamentos.jpg.asset-DOlNU08t.js"]
	}
} });
//#endregion
export { tsrStartManifest };
